How to Compile and Run the Programs

Note: The following programs run on Linux. 

Project1
In the command prompt, type 
	g++ -Wall -w -std=c++11 -pthread project1.cpp -o main
to create the executable file. Then type the following to run the program. 
	./main
Output: The output will state the number of threads, the final matrix, and execution time. 

Project2 -- not added in the repo yet
In the command prompt, type 
	g++ -Wall -w -std=c++11 -pthread project2.cpp -o main
to create the executable file. Then type the following to run the program. 
	./main
Output: The output will state the number of threads, the final matrix, and execution time. 
