How to Compile and Run the Programs

Note: The following programs run on Linux. 

Sequential 
In the command prompt, type 
	g++ sequential.cpp -o main
to create the executable file. Then type the following to run the program. 
	./main
Output: The output will be the strings used and execution time. 